package slave

import bean.HeartMsg
import bean.HttpMsg
import bean.Msg
import bean.ProxyResponseMsg
import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import com.google.gson.reflect.TypeToken
import http.HttpUtils
import io.reactivex.Flowable
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import okhttp3.MediaType
import okhttp3.RequestBody
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.channels.AlreadyConnectedException
import java.nio.channels.SocketChannel
import java.nio.charset.Charset
import java.util.*
import java.util.concurrent.TimeUnit

/**
 * Created by huang on 2017/6/20.
 */

object Slave {

    private var defHost = "http://47.74.133.156:80"
    private var address: InetSocketAddress = InetSocketAddress("localhost", 65000)
    private var disposable: Disposable? = null
    private @Volatile var socketChannel: SocketChannel = SocketChannel.open()
    private val httpMsg = Msg()
    private val heartMsg = HeartMsg()
    private val gson = Gson()
    var readCount: Int = 0
    private val bufferSize = 8 * 1024
    private val readBuffer = ByteBuffer.allocate(bufferSize)
    private val sendMsgBuffer: ByteBuffer = ByteBuffer.allocate(bufferSize)
    private val base64Encoder: Base64.Encoder = Base64.getEncoder()

    const val HTTP_PROXY_RESPONSE = "http_proxy_response"
    const val HTTP_REQUEST = "http_request"
    const val HTTP_HEARTBEAT = "heartbeat"

    fun connect(): Boolean {
        synchronized(socketChannel) {
            try {
                if (!socketChannel.isOpen) {
                    socketChannel = SocketChannel.open()
                }
                return try {
                    val connect = socketChannel.connect(address)
                    println("------------connect--------------")
                    println("连接主机成功!")
                    println("主机地址:" + socketChannel.remoteAddress.toString())
                    println("------------connect-------------")
                    connect
                } catch (e: AlreadyConnectedException) {
                    e.printStackTrace()
                    socketChannel.close()
                    println("#####")
                    println("与主机断开连接!!")
                    println("#####")
                    false
                }
            } catch (e: Exception) {
                e.printStackTrace()
                return false
            }
        }
    }

    private fun runHeartbeatAndReconnect() {
        disposable = Flowable.interval(1, TimeUnit.SECONDS, Schedulers.newThread())
                .forEach {
                    heartMsg.timestamp = System.currentTimeMillis() / 1000
                    if (!sendMsg(HTTP_HEARTBEAT, heartMsg, socketChannel)) {
                        connect()
                    }
                }
    }

    fun slaveServerStart(host: String, port: Int, dsc: String, weight: Short = 5) {
        defHost = dsc
        address = InetSocketAddress(host, port)
        heartMsg.uuid = UUID.randomUUID().toString()
        heartMsg.weight = weight
        connect()
        runHeartbeatAndReconnect()

        while (true) {
            println("等待!")
            if (!readMsg(socketChannel)) {
                Thread.sleep(5000)
                continue
            }
        }
    }

    fun readMsg(socketChannel: SocketChannel): Boolean {
        if (!socketChannel.isOpen) return false
        readBuffer.clear()
        readCount = 0
        try {
            readCount = socketChannel.read(readBuffer)
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }

        if (readCount == -1) {
            socketChannel.close()
            return false
        }

        val msg = analysisMsg(readBuffer, readCount)
        if (msg != null) {

            println(readCount)
            println(String(readBuffer.array().copyOf(readCount)))

            processMsg(msg.opt, msg.data)
        }
        return true
    }

    fun analysisMsg(byteBuffer: ByteBuffer, readCount: Int): Msg? {
        if (readCount <= 0) return null
        val str = String(byteBuffer.array().copyOf(readCount), Charset.defaultCharset())
        try {
            val json = gson.fromJson(str, Msg::class.java)
            return json
        } catch (e: JsonSyntaxException) {
            return null
        }
    }

    fun processMsg(opt: String?, data: String?) {
        if (data == null || opt == null) return
        when (opt) {
            HTTP_REQUEST -> {
                val httpMsg = gson.fromJson(data, HttpMsg::class.java)
                if (httpMsg != null) {
                    println(httpMsg)
                    when (httpMsg.method) {
                        HttpUtils.GET -> {
                            val type = object : TypeToken<HashMap<String, String>>() {}.type
                            val headers = gson.fromJson<HashMap<String, String>>(httpMsg.headers, type)
                            val response = HttpUtils.get(defHost + httpMsg.uri, headers)
                            if (httpMsg.isSync!!) {
                                if (response == null) {
                                    sendMsg(HTTP_PROXY_RESPONSE, ProxyResponseMsg("从机器任务执行失败", httpMsg.uuid), socketChannel)
                                } else {
                                    val msg = base64Encoder.encodeToString(response.body().bytes())
                                    sendMsg(HTTP_PROXY_RESPONSE, ProxyResponseMsg(msg, httpMsg.uuid), socketChannel)
                                }
                            }
                        }
                        HttpUtils.POST -> {
                            val type = object : TypeToken<HashMap<String, String>>() {}.type
                            val headers = gson.fromJson<HashMap<String, String>>(httpMsg.headers, type)
                            val body = RequestBody.create(MediaType.parse("text"), Base64.getDecoder().decode(httpMsg.content))
                            println(body.toString())
                            val response = HttpUtils.post(defHost + httpMsg.uri, body, headers)
                            println(response.toString())
                        }
                    }
                }
            }
        }
    }

    fun <T> sendMsg(opt: String, data: T? = null, socketChannel: SocketChannel): Boolean {
        if (!socketChannel.isOpen) return false
        httpMsg.opt = opt
        if (data != null) {
            httpMsg.data = gson.toJson(data)
        }
        sendMsgBuffer.clear()
        sendMsgBuffer.put(gson.toJson(httpMsg).toByteArray())
        sendMsgBuffer.flip()
        while (sendMsgBuffer.hasRemaining()) {
            try {
                socketChannel.write(sendMsgBuffer)
            } catch (e: Exception) {
                e.printStackTrace()
                return false
            }
        }
        return true
    }

    private fun close() {
        if (disposable?.isDisposed != null) {
            disposable!!.dispose()
        }
        socketChannel.close()
    }

}