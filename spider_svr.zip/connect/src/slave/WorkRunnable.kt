package slave

import java.nio.ByteBuffer
import java.nio.channels.SocketChannel

/**
 * Created by huang on 2017/6/23.
 */

class WorkRunnable(val socketChannel: SocketChannel) : Runnable {

    var readCount: Int = 0
    private val readBufferSize = 8 * 1024
    private val readBuffer = ByteBuffer.allocate(readBufferSize)
    override fun run() {
        while (true) {
            println("等待!")
            try {
                readBuffer.clear()
                readCount = socketChannel.read(readBuffer)
                print(readCount)
            } catch (e: Exception) {
                e.printStackTrace()
                Thread.sleep(5000)
                continue
            }
            if (readCount > 0) {
                println(readCount)
                println(String(readBuffer.array().copyOf(readCount)))
            }

        }

    }
}