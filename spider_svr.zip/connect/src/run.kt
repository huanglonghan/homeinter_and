import slave.Slave

/**
 * Created by huang on 2017/6/26.
 */
fun main(args: Array<String>) {
    if (args.isEmpty()) {
        println("参数错误!")
        println("格式:java -jar *.jar localhost 80 [sdst(url)]")
    } else {
        var dstUrl = "http://localhost"
        if (args.size == 3) {
            dstUrl = args[2]
        }
        Slave.slaveServerStart(args[0], args[1].toInt(), dstUrl)
    }
}