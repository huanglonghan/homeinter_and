package bean

/**
 * Created by huang on 2017/6/26.
 */

data class Msg(var opt: String? = null, var data: String? = null)

data class HttpMsg(var uuid: String? = null, var isSync: Boolean? = null, var uri: String? = null, var content: String? = null, var headers: String? = null, var method: String? = null)

data class HeartMsg(var uuid: String? = null, var weight: Short? = null, var timestamp: Long? = null)

data class ProxyResponseMsg( var msg: String? = null,var uuid: String? = null)