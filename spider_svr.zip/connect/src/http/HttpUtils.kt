package http

import okhttp3.*
import java.io.IOException


/**
 * Created by huang on 2017/6/26.
 */
object HttpUtils {
    private val okHttpClient: OkHttpClient
    private val requestCall: HashMap<String, Call> = hashMapOf()
    const val POST = "POST"
    const val GET = "GET"

    init {
        val builder = OkHttpClient.Builder()
        okHttpClient = builder.build()
    }

    fun get(url: String, headers: HashMap<String, String>? = null): Response? {
        val builder = Request.Builder()
                .url(url)
        if (headers != null) {
            for ((key, value) in headers) {
                builder.addHeader(key, value)
            }
        }
        return request(builder)
    }

    fun post(url: String, body: RequestBody, headers: HashMap<String, String>? = null): Response? {
        val builder = Request.Builder()
                .url(url)
        if (headers != null) {
            for ((key, value) in headers) {
                builder.addHeader(key, value)
            }
        }
        builder.post(body)
        return request(builder)
    }

    private fun request(builder: Request.Builder): Response? {
        val request = builder.build()
        val call = okHttpClient.newCall(request)
        requestCall.put(request.url().toString(), call)
        try {
            return call.execute()
        } catch (e: IOException) {
            return null
        }
    }
}