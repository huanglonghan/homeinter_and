package utils

import com.google.gson.Gson
import master.service.config.config.Companion.HTTP_SUCCEED
import master.service.config.config.Companion.HTTP_SUCCEED_MSG

/**
 * Created by huang on 2017/6/23.
 */

class Utils {

    //{status: 200, msg: "请求成功", data: {login: false}}
    data class Result<T>(var status: Int, var msg: String, var data: T)

    companion object {
        @JvmStatic fun <T> genResult(data: T, status: Int = HTTP_SUCCEED, msg: String = HTTP_SUCCEED_MSG): String {
            if (data is String) {
                return String.format("{\"status\": %d, \"msg\" : \"%s\", \"data\": \"%s\"}", status, msg, data)
            } else {
                return Gson().toJson(Result(status, msg, data))
            }
        }

        @JvmStatic fun getCurrentTimestamp(): Long {
            return System.currentTimeMillis() / 1000
        }
    }

}