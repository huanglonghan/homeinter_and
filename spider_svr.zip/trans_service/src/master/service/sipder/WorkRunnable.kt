package service.sipder

import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import master.service.bean.HeartMsg
import master.service.bean.Msg
import master.service.bean.ProxyResponseMsg
import master.service.config.config.Companion.DEF_BUFFER_SIZE
import utils.Utils
import java.nio.ByteBuffer
import java.nio.channels.SocketChannel
import java.util.*

/**
 * Created by huang on 2017/6/23.
 */
class WorkRunnable(val socketChannel: SocketChannel) : Runnable {

    val readBuffer: ByteBuffer = ByteBuffer.allocate(DEF_BUFFER_SIZE)
    val gson = Gson()
    private val base64Decoder = Base64.getDecoder()

    override fun run() {
        if (!readMsg(socketChannel)) {
            SpiderManager.removeInvalidClient(socketChannel)
            socketChannel.close()
        }
    }

    fun readMsg(socketChannel: SocketChannel): Boolean {
        if (!socketChannel.isOpen) {
            SpiderManager.removeInvalidClient(socketChannel)
            return false
        }
        readBuffer.clear()
        try {
            val readBytes = socketChannel.read(readBuffer)
            if (readBytes == -1) {
                SpiderManager.removeInvalidClient(socketChannel)
                return false
            }
            println(readBytes)
            val msg = analysisMsg(readBuffer, readBytes)
            if (msg != null) {
                processMsg(msg.opt, msg.data)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
        return true
    }

    fun analysisMsg(byteBuffer: ByteBuffer, readCount: Int): Msg? {
        if (readCount <= 0) return null
        val str = String(byteBuffer.array().copyOf(readCount), Charsets.UTF_8)
        try {
            val json = gson.fromJson(str, Msg::class.java)
            return json
        } catch (e: JsonSyntaxException) {
            e.printStackTrace()
            return null
        }
    }

    fun processMsg(opt: String?, data: String?) {
        val timestamp = Utils.getCurrentTimestamp()
        if (data == null || opt == null) return
        when (opt) {
            "heartbeat" -> {
                val heartMsg = gson.fromJson(data, HeartMsg::class.java)
                if (heartMsg != null) {
                    heartMsg.timestamp = timestamp
                    SpiderManager.addClient(heartMsg, socketChannel)
                }
            }
            "http_proxy_response" -> {
                val proxyResponseMsg = gson.fromJson(data, ProxyResponseMsg::class.java)
                if (proxyResponseMsg != null) {
                    val ret = base64Decoder.decode(proxyResponseMsg.msg)
                    if (SpiderManager.syncTasks.contains(key = proxyResponseMsg.uuid)) {
                        SpiderManager.syncTasks[proxyResponseMsg.uuid]!!.second(String(ret))
                        SpiderManager.syncTasks.remove(proxyResponseMsg.uuid)
                    }
                }
            }
        }
    }
}