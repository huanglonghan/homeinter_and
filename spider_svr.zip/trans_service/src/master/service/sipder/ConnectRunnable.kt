package service.sipder

import java.nio.channels.SelectionKey
import java.nio.channels.Selector
import java.nio.channels.ServerSocketChannel

/**
 * Created by huang on 2017/6/23.
 */
class ConnectRunnable(val serverSelector: Selector, val clientSelector: Selector) : Runnable {
    override fun run() {
        while (true) {
            if (serverSelector.select(10000) <= 0) continue
            val keys = serverSelector.selectedKeys().iterator()
            while (keys.hasNext()) {
                val key = keys.next()
                keys.remove()  // 删除此消息
                if (key.isAcceptable) {
                    val channel = key.channel() as? ServerSocketChannel
                    val clientChannel = channel?.accept()
                    clientChannel?.configureBlocking(false)
                    clientSelector.wakeup()
                    clientChannel?.register(clientSelector, SelectionKey.OP_READ)
                }
            }
        }
    }
}