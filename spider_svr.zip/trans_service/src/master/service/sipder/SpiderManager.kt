package service.sipder

import com.google.gson.Gson
import io.reactivex.Flowable
import io.reactivex.schedulers.Schedulers
import master.service.bean.HeartMsg
import master.service.bean.Info
import master.service.bean.Msg
import master.service.config.config.Companion.DEF_TCP_SERVER_HOST
import master.service.config.config.Companion.DEF_TCP_SERVER_PORT
import master.service.config.config.Companion.SYNC_TIMEOUT
import utils.Utils
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.channels.SelectionKey
import java.nio.channels.Selector
import java.nio.channels.ServerSocketChannel
import java.nio.channels.SocketChannel
import java.nio.channels.spi.SelectorProvider
import java.util.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Created by huang on 2017/6/23.
 */
object SpiderManager {

    data class MachineInfo(var timestamp: Long, var machine: SocketChannel)

    data class SelectResult(val weight: Short, val uuid: String)

    var machineList: ConcurrentHashMap<Short, ConcurrentHashMap<String, MachineInfo>> = ConcurrentHashMap()

    val syncTasks = ConcurrentHashMap<String?, Pair<Long, (str: String?) -> Unit>>()
    val gson = Gson()
    private const val connectTimeout = 5

    private val httpMsgBuffer: ByteBuffer = ByteBuffer.allocate(DEFAULT_BUFFER_SIZE)
    private val httpMsg: Msg = Msg()

    fun runSpiderManageServer(port: Int = DEF_TCP_SERVER_PORT, host: String = DEF_TCP_SERVER_HOST) {
        machineList.clear()

        val provider = SelectorProvider.provider()
        val serverSelector: Selector = provider.openSelector()
        val clientSelector: Selector = provider.openSelector()

        val address = InetSocketAddress(host, port)
        val serverChannel = ServerSocketChannel.open()
        serverChannel.socket().bind(address)
        serverChannel.configureBlocking(false)
        serverChannel.register(serverSelector, SelectionKey.OP_ACCEPT)
        Thread(ConnectRunnable(serverSelector, clientSelector)).start()
        Thread(ControlRunnable(clientSelector)).start()
        runRemoveInvalidClient()
        runRemoveInvalidSyncTask()
    }

    fun runRemoveInvalidClient() {
        Flowable.interval(2, TimeUnit.SECONDS, Schedulers.newThread())
                .forEach {
                    try {
                        removeTimeoutClient()

                        var machineCount = 0
                        SpiderManager.machineList.values.forEach {
                            it.forEach { _: String, _: SpiderManager.MachineInfo ->
                                machineCount++
                            }
                        }
                        val machineList = SpiderManager.machineList.values
                                .asSequence()
                                .flatMap { it.values.asSequence() }
                                .mapTo(LinkedList<String>()) { it.machine.remoteAddress.toString() }
                        println(gson.toJson(Info(machineCount, machineList)))
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
    }

    fun runRemoveInvalidSyncTask() {
        Flowable.interval(5, TimeUnit.SECONDS, Schedulers.newThread())
                .forEach {
                    try {
                        val tasks = syncTasks.iterator()
                        while (tasks.hasNext()) {
                            val task = tasks.next()
                            if (task.value.first + SYNC_TIMEOUT < Utils.getCurrentTimestamp()) {
                                tasks.remove()
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
    }

    //获取机器策略,修改这里 默认重试5次
    fun getValidateMachine(): SocketChannel? {
        if (machineList.size <= 0) return null
        var i = 5
        while (i >= 0) {
            i--
            val pos = weightedRandom()
            if (pos != null) {
                val machines = machineList[pos.weight] ?: continue
                val machine = machines[pos.uuid] ?: continue
                if (!testValidate(machine.machine)) {
                    machines.remove(pos.uuid)
                    continue
                } else {
                    return machine.machine
                }
            }
        }
        return null
    }

    //加权随机算法
    private fun weightedRandom(): SelectResult? {
        var weightSum = 0
        for ((weight, map) in machineList) {
            for ((_, _) in map) {
                weightSum += weight
            }
        }
        val pos = Random().nextInt(weightSum) + 1

        var indexSum = 0
        val list = machineList.iterator()
        while (list.hasNext()) {
            val set = list.next()
            val machines = set.value.iterator()
            while (machines.hasNext()) {
                val machine = machines.next()
                indexSum += set.key
                if (indexSum >= pos) {
                    return SelectResult(set.key, machine.key)
                }
            }
        }
        return null
    }

    private fun testValidate(socketChannel: SocketChannel): Boolean {
        if (socketChannel.isOpen) {
            return sendMsg("test", null, socketChannel)
        } else {
            return false
        }
    }

    fun <T> sendMsg(opt: String, data: T? = null, socketChannel: SocketChannel): Boolean {
        if (!socketChannel.isOpen) {
            removeInvalidClient(socketChannel)
            return false
        }
        httpMsg.opt = opt
        if (data != null) {
            httpMsg.data = gson.toJson(data)
        } else {
            httpMsg.data = data
        }
        httpMsgBuffer.clear()
        httpMsgBuffer.put(gson.toJson(httpMsg).toByteArray())
        httpMsgBuffer.flip()
        while (httpMsgBuffer.hasRemaining()) {
            try {
                socketChannel.write(httpMsgBuffer)
            } catch (e: Exception) {
                e.printStackTrace()
                return false
            }
        }
        return true
    }

    fun addClient(heartMsg: HeartMsg, socketChannel: SocketChannel) {
        val machine: ConcurrentHashMap<String, MachineInfo>
        if (machineList.contains(key = heartMsg.weight)) {
            machine = machineList[heartMsg.weight]!!
            if (machine.contains(key = heartMsg.uuid)) {
                machine[heartMsg.uuid!!] = MachineInfo(heartMsg.timestamp, socketChannel)
            } else {
                machine.put(heartMsg.uuid!!, MachineInfo(heartMsg.timestamp, socketChannel))
            }
        } else {
            machine = ConcurrentHashMap<String, MachineInfo>()
            machine.put(heartMsg.uuid!!, MachineInfo(heartMsg.timestamp, socketChannel))
            machineList.put(heartMsg.weight, machine)
        }
    }

    fun removeTimeoutClient() {
        val weights = machineList.iterator()
        while (weights.hasNext()) {
            val machines = weights.next()
            val machine = machines.value.iterator()
            while (machine.hasNext()) {
                val info = machine.next()
                if (Utils.getCurrentTimestamp() > info.value.timestamp + 5) {
                    machine.remove()
                }
            }
        }
    }

    fun removeInvalidClient(socketChannel: SocketChannel) {
        val weights = machineList.iterator()
        while (weights.hasNext()) {
            val machines = weights.next()
            val machine = machines.value.iterator()
            while (machine.hasNext()) {
                val info = machine.next()
                if (info.value.machine === socketChannel) {
                    machine.remove()
                }
            }
        }
    }
}