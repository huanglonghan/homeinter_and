package service.http

import com.google.gson.Gson
import io.netty.buffer.Unpooled
import io.netty.channel.ChannelHandlerContext
import io.netty.channel.ChannelInboundHandlerAdapter
import io.netty.handler.codec.http.*
import io.netty.handler.codec.http.HttpHeaderNames.*
import master.service.bean.Http
import master.service.bean.HttpMsg
import master.service.bean.Info
import master.service.config.config.Companion.HTTP_SUCCEED
import service.sipder.SpiderManager
import utils.Utils
import java.util.*


/**
 * Created by huang on 2017/6/20.
 */

class ServerHandler : ChannelInboundHandlerAdapter() {

    private val httpMsg: HttpMsg = HttpMsg()
    private val gson: Gson = Gson()
    private val base64Encoder: Base64.Encoder = Base64.getEncoder()
    private var request: HttpRequest? = null
    var isResponse: Boolean = false

    override fun channelRead(ctx: ChannelHandlerContext?, msg: Any?) {
        when (msg) {
            is HttpRequest -> {
                request = msg
            }
            is HttpContent -> {
                val http = analysisMsg(request, msg)
                if (http != null) {
                    val result = processMsg(ctx, http)
                    if (result != null) {
                        sendMsg(ctx, result)
                    }
                } else {
                    sendMsg(ctx, Utils.genResult("", HTTP_SUCCEED, "参数错误,或请求方法错误,目前仅支持GET方法"))
                }
            }
        }
        super.channelRead(ctx, msg)
    }

    private fun analysisMsg(request: HttpRequest?, content: HttpContent): Http? {
        if (request == null) return null
        println(request.uri())
        when (request.method()) {
            HttpMethod.GET -> {
                return Http(request.uri().httpParseParam(), request.headers().parseHeaders(),
                        request.method(), request.uri())
            }
            HttpMethod.POST -> {
//                val buf = content.copy().content()
//                val req = ByteArray(buf.readableBytes())
//                buf.readBytes(req)
//                buf.release()
                return null
            }
            else -> return null
        }
    }

    private fun processMsg(ctx: ChannelHandlerContext?, msg: Http): String? {
        val action = msg.param["opt"] ?: return Utils.genResult("无效参数:opt")
        when (action) {
            "status" -> {
                var machineCount = 0
                SpiderManager.machineList.values.forEach {
                    it.forEach { _: String, _: SpiderManager.MachineInfo ->
                        machineCount++
                    }
                }
                val machineList = SpiderManager.machineList.values
                        .asSequence()
                        .flatMap { it.values.asSequence() }
                        .mapTo(LinkedList<String>()) { it.machine.remoteAddress.toString() }
                return Utils.genResult(Info(machineCount, machineList))
            }
            "async" -> {
                return proxyRequest(ctx, msg, false)
            }
            "sync" -> {
                isResponse = false
                return proxyRequest(ctx, msg, true)
            }
            else -> {
                return Utils.genResult("", HTTP_SUCCEED, "找不到action: ?a=" + action)
            }
        }
    }

    fun proxyRequest(ctx: ChannelHandlerContext?, msg: Http, isSync: Boolean): String? {
        httpMsg.headers = gson.toJson(msg.header)
        httpMsg.uri = msg.uri
        httpMsg.method = msg.method.name()
        httpMsg.uuid = UUID.randomUUID().toString()

        if (msg.content != null) {
            httpMsg.content = base64Encoder.encodeToString(msg.content)
        }
        val machine = SpiderManager.getValidateMachine()
        if (machine != null) {
            httpMsg.isSync = isSync
            val result = SpiderManager.sendMsg("http_request", httpMsg, machine)
            if (!result) {
                return Utils.genResult("", HTTP_SUCCEED, "发布任务失败")
            }
            if (isSync) {
                SpiderManager.syncTasks.put(httpMsg.uuid, Pair(Utils.getCurrentTimestamp(), {
                    str: String? ->
                    var ret = "该同步任务处理任务耗时过长,主机主动关闭该同步任务响应,请试用异步任务"
                    if (str != null) {
                        ret = str
                    }
                    sendMsg(ctx, Utils.genResult("", HTTP_SUCCEED, ret))
                    ctx?.close()
                    return@Pair
                }))
                return null
            } else {
                return Utils.genResult("发布任务成功,静待佳音!")
            }
        } else {
            return Utils.genResult("", HTTP_SUCCEED, "无可用机器")
        }
    }

//    fun SocketChannel.getIp(): String {
//        val str = this.remoteAddress.toString()
////        return str.substring(1, str.lastIndexOf(':'))
//    }


    fun String.httpParseParam(): HashMap<String, String> {
        val temp = this.substring(this.indexOf('?') + 1)
        val params = temp.split('&')
        val paramMap = hashMapOf<String, String>()
        params.asSequence()
                .map { it.split('=') }
                .filter { it.size >= 2 }
                .forEach { paramMap.put(it[0], it[1]) }
        return paramMap
    }

    fun HttpHeaders.parseHeaders(): HashMap<String, String> {
        val headersMap = hashMapOf<String, String>()
        this.forEach {
            headersMap.put(it.key, it.value)
        }
        return headersMap
    }


    private fun sendMsg(ctx: ChannelHandlerContext?, data: String) {
        val response = DefaultFullHttpResponse(HttpVersion.HTTP_1_1,
                HttpResponseStatus.OK, Unpooled.wrappedBuffer(data.toByteArray(charset("UTF-8"))))
        response.headers().set(CONTENT_TYPE, "json/application")
        response.headers().set(CONTENT_ENCODING, "utf-8")
        response.headers().set(CONTENT_LENGTH,
                response.content().readableBytes())
        ctx?.write(response)
        ctx?.flush()
    }

    override fun channelReadComplete(ctx: ChannelHandlerContext?) {
        if (httpMsg.isSync == null || (httpMsg.isSync!! and isResponse)) {
            ctx?.close()
        }
    }
}
