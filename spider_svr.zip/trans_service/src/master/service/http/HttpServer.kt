package service.http

import io.netty.bootstrap.ServerBootstrap
import io.netty.channel.ChannelInitializer
import io.netty.channel.ChannelOption
import io.netty.channel.nio.NioEventLoopGroup
import io.netty.channel.socket.SocketChannel
import io.netty.channel.socket.nio.NioServerSocketChannel
import io.netty.handler.codec.http.HttpRequestDecoder
import io.netty.handler.codec.http.HttpResponseEncoder
import master.service.config.config.Companion.DEF_HTTP_SERVER_HOST
import master.service.config.config.Companion.DEF_HTTP_SERVER_PORT
import java.net.InetSocketAddress

/**
 * Created by huang on 2017/6/20.
 */

object HttpServer {
    fun runHttpServer(port: Int = DEF_HTTP_SERVER_PORT, host: String = DEF_HTTP_SERVER_HOST) {
        val address = InetSocketAddress(host, port)
        val bossGroup = NioEventLoopGroup()
        val workerGroup = NioEventLoopGroup()
        try {
            val b = ServerBootstrap()
            b.group(bossGroup, workerGroup)
                    .channel(NioServerSocketChannel::class.java)
                    .childHandler(object : ChannelInitializer<SocketChannel>() {
                        @Throws(Exception::class)
                        public override fun initChannel(ch: SocketChannel) {
                            ch.pipeline().addLast(HttpResponseEncoder())
                            ch.pipeline().addLast(HttpRequestDecoder())
                            ch.pipeline().addLast(ServerHandler())
                        }
                    })
                    .option(ChannelOption.SO_BACKLOG, 128)
                    .childOption(ChannelOption.SO_KEEPALIVE, true)
                    .childOption(ChannelOption.TCP_NODELAY, false)

            // 绑定端口，开始接收进来的连接
            val f = b.bind(address).sync()

            // 等待服务器  socket 关闭 。
            // 在这个例子中，这不会发生，但你可以优雅地关闭你的服务器。
            f.channel().closeFuture().sync()
        } finally {
            workerGroup.shutdownGracefully()
            bossGroup.shutdownGracefully()
        }

    }
}