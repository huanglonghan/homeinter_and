package master.service.config

/**
 * Created by huang on 2017/6/28.
 */
class config {
    companion object {
        const val DEF_TCP_SERVER_PORT = 9501
        const val DEF_TCP_SERVER_HOST = "0.0.0.0"
        const val DEF_HTTP_SERVER_PORT = DEF_TCP_SERVER_PORT + 1
        const val DEF_HTTP_SERVER_HOST = DEF_TCP_SERVER_HOST
        const val HTTP_SUCCEED = 200
        const val HTTP_SUCCEED_MSG = "OK"
        const val DEF_BUFFER_SIZE = 8*1024
        const val SYNC_TIMEOUT = 10
    }
}