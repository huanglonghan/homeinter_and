import service.http.HttpServer
import service.sipder.SpiderManager

/**
 * Created by huang on 2017/6/20.
 */

fun main(args: Array<String>) {
    if (args.isEmpty()) {
        println("参数错误!")
        println("格式:java -jar *.jar localhost 65000(tcp) [80(http)]")
    } else {
        var httpPort = args[1].toInt() + 1
        if (args.size >= 3) {
            httpPort = args[2].toInt()
        }
        SpiderManager.runSpiderManageServer(args[1].toInt(), args[0])
        HttpServer.runHttpServer(httpPort, args[0])
    }
}
