package slave

import Logging
import bean.HeartMsg
import bean.Msg
import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import config.config
import io.reactivex.Flowable
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.channels.AlreadyConnectedException
import java.nio.channels.SocketChannel
import java.nio.charset.Charset
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Created by huang on 2017/6/20.
 */

object Slave {

    private var address: InetSocketAddress? = null
    private var disposable: Disposable? = null
    private @Volatile var socketChannel: SocketChannel = SocketChannel.open()
    private val httpMsg = Msg()
    private val heartMsg = HeartMsg()
    private val gson = Gson()
    var readCount: Int = 0
    val pool: ExecutorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors() * 4)

    private val readBuffer = ByteBuffer.allocate(config.buffer_size)
    private val sendMsgBuffer: ByteBuffer = ByteBuffer.allocate(config.buffer_size)
    private val base64Encoder: Base64.Encoder = Base64.getEncoder()

    fun connect(): Boolean {
        synchronized(socketChannel) {
            try {
                if (!socketChannel.isOpen) {
                    socketChannel = SocketChannel.open()
                }
                return try {
                    val connect = socketChannel.connect(address)
                    connect
                } catch (e: AlreadyConnectedException) {
                    socketChannel.close()
                    false
                }
            } catch (e: Exception) {
                return false
            }
        }
    }

    private fun runHeartbeatAndReconnect() {
        disposable = Flowable.interval(1, TimeUnit.SECONDS, Schedulers.newThread())
                .forEach {
                    heartMsg.timestamp = System.currentTimeMillis() / 1000
                    if (!sendMsg(config.HTTP_HEARTBEAT, heartMsg, socketChannel)) {
                        connect()
                    }
                }
    }

    fun slaveServerStart() {
        address = InetSocketAddress(config.server_host, config.server_port)
        heartMsg.uuid = UUID.randomUUID().toString()
        heartMsg.weight = config.slave_weight
        connect()
        runHeartbeatAndReconnect()

        while (true) {
            if (!readMsg(socketChannel)) {
                Thread.sleep(5000)
                continue
            }
        }
    }

    fun readMsg(socketChannel: SocketChannel): Boolean {
        if (!socketChannel.isOpen) return false
        readBuffer.clear()
        readCount = 0
        try {
            readCount = socketChannel.read(readBuffer)
        } catch (e: Exception) {
            return false
        }

        if (readCount == -1) {
            socketChannel.close()
            return false
        }

        val msg = analysisMsg(readBuffer, readCount)
        if (msg != null) {
            processMsg(msg.opt, msg.data)
        }
        return true
    }

    fun analysisMsg(byteBuffer: ByteBuffer, readCount: Int): Msg? {
        if (readCount <= 0) return null
        val str = String(byteBuffer.array().copyOf(readCount), Charset.defaultCharset())
        try {
            val json = gson.fromJson(str, Msg::class.java)
            return json
        } catch (e: JsonSyntaxException) {
            return null
        }
    }

    fun processMsg(opt: String?, data: String?) {
        if (data == null || opt == null) return
        when (opt) {
            config.HTTP_PROXY_REQUEST -> {
                pool.execute(WorkRunnable(data, socketChannel))
            }
        }
    }

    fun <T> sendMsg(opt: String, data: T? = null, socketChannel: SocketChannel): Boolean {
        if (!socketChannel.isOpen) return false
        httpMsg.opt = opt
        if (data != null) {
            httpMsg.data = gson.toJson(data)
        }
        sendMsgBuffer.clear()
        sendMsgBuffer.put(gson.toJson(httpMsg).toByteArray())
        sendMsgBuffer.flip()
        while (sendMsgBuffer.hasRemaining()) {
            try {
                socketChannel.write(sendMsgBuffer)
                Logging.log.info(gson.toJson(httpMsg))
            } catch (e: Exception) {
                return false
            }
        }
        return true
    }

    private fun close() {
        if (disposable?.isDisposed != null) {
            disposable!!.dispose()
        }
        socketChannel.close()
    }

}