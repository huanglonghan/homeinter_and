package slave

import bean.HttpMsg
import bean.ProxyResponseMsg
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import config.config
import http.HttpUtils
import okhttp3.MediaType
import okhttp3.RequestBody
import slave.Slave.sendMsg
import java.nio.channels.SocketChannel
import java.util.*

/**
 * Created by huang on 2017/6/23.
 */

class WorkRunnable(val data: String, val socketChannel: SocketChannel) : Runnable {

    private val gson = Gson()

    override fun run() {
        val httpMsg = gson.fromJson(data, HttpMsg::class.java)
        if (httpMsg != null) {
            when (httpMsg.method) {
                HttpUtils.GET -> {
                    val type = object : TypeToken<HashMap<String, String>>() {}.type
                    val headers = gson.fromJson<HashMap<String, String>>(httpMsg.headers, type)
                    val response = HttpUtils.get(config.dstHost + httpMsg.uri, headers)
                    if (httpMsg.isSync!!) {
                        if (response == null) {
                            sendMsg(config.HTTP_PROXY_RESPONSE, ProxyResponseMsg("从机器任务执行失败", httpMsg.uuid), socketChannel)
                        } else {
                            val bytes = response.body().bytes()
                            val msg: String
                            if (bytes != null) {
                                msg = Base64.getEncoder().encodeToString(bytes)
                            } else {
                                msg = "目标服务器没有响应!!"
                            }
                            sendMsg(config.HTTP_PROXY_RESPONSE, ProxyResponseMsg(msg, httpMsg.uuid), socketChannel)
                        }
                    }
                }
                HttpUtils.POST -> {
                    val type = object : TypeToken<HashMap<String, String>>() {}.type
                    val headers = gson.fromJson<HashMap<String, String>>(httpMsg.headers, type)
                    val body = RequestBody.create(MediaType.parse("text"), Base64.getDecoder().decode(httpMsg.content))
                    val response = HttpUtils.post(config.dstHost + httpMsg.uri, body, headers)
                }
            }
        }
    }
}