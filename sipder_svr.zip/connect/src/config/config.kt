package config

/**
 * Created by huang on 2017/6/29.
 */
object config {

    private const val DEF_SERVER_HOST = "0.0.0.0"
    private const val DEF_SERVER_PORT = 9501
    private const val DEF_DST_HOST = "http://localhost"

    private const val DEF_BUFFER_SIZE = 8 * 1024
    private const val DEF_SLAVE_WEIGHT:Short = 5
    private const val DEF_PROXY_CONNECT_TIMEOUT:Long = 10
    private const val DEF_PROXY_READ_TIMEOUT:Long = 10
    private const val DEF_PROXY_WRITE_TIMEOUT:Long = 10

    internal const val HTTP_PROXY_REQUEST = "http_request"
    internal const val HTTP_PROXY_RESPONSE = "http_proxy_response"
    internal const val HTTP_HEARTBEAT = "heartbeat"

    internal var slave_weight = DEF_SLAVE_WEIGHT
    internal var server_host = DEF_SERVER_HOST
    internal var server_port = DEF_SERVER_PORT
    internal var dstHost = DEF_DST_HOST
    internal var buffer_size = DEF_BUFFER_SIZE
    internal var proxy_connect_timeout = DEF_PROXY_CONNECT_TIMEOUT
    internal var proxy_read_timeout = DEF_PROXY_READ_TIMEOUT
    internal var proxy_write_timeout = DEF_PROXY_WRITE_TIMEOUT

}
