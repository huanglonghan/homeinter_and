import config.config
import org.apache.commons.cli.DefaultParser
import org.apache.commons.cli.Options
import org.apache.log4j.Logger
import org.apache.log4j.PropertyConfigurator
import org.ini4j.Ini
import slave.Slave
import java.io.File
import java.util.*

/**
 * Created by huang on 2017/6/26.
 */

object Logging {
    private var _logging: Logger? = null
    val log: Logger
        get() {
            if (_logging == null) {
                _logging = Logger.getLogger("main.class")
            }
            return Logger.getLogger("main.class")
        }
}

fun main(args: Array<String>) {

    val parser = DefaultParser()
    val options = Options()
    options.addOption("c", "config", true, "config file path")
    options.addOption("l", "log", true, "log path")
    options.addOption("h", "help", false, "help description")

    val commandLine = parser.parse(options, args)

    if (commandLine.hasOption('h')) {
        System.out.println("Demo: java -jar *.jar -c path [-l path]")
        System.exit(0)
        return
    }

    var logPath = ""
    if (commandLine.hasOption('l')) {
        logPath = commandLine.getOptionValue('l')
    }
    loggingConfig(logPath)

    if (!commandLine.hasOption('c')) {
        System.out.println("Demo: java -jar *.jar -c path")
        System.exit(0)
        return
    }
    val path = commandLine.getOptionValue('c')
    val ini: Ini
    try {
        ini = Ini(File(path))
        initConfig(ini)
    } catch (e: Exception) {
        System.out.println("config file format error !")
        System.exit(0)
        return
    }

    Logging.log.info("启动成功!!")
    Logging.log.info("主机地址:" + config.server_host + ":" + config.server_port)
    Slave.slaveServerStart()

}

fun initConfig(ini: Ini) {
    val serverHost = ini.get("moplus", "server_host")
    val serverPort = ini.get("moplus", "server_port")
    val bufferSize = ini.get("moplus", "msg_buffer_size")
    val weight = ini.get("moplus", "weight")
    val tranHost = ini.get("moplus", "dst_host")
    val proxyConnectTimeout = ini.get("moplus", "proxy_connect_timeout")
    val proxyReadTimeout = ini.get("moplus", "proxy_read_timeout")
    val proxyWriteTimeout = ini.get("moplus", "proxy_write_timeout")

    if (serverHost != null) {
        config.server_host = serverHost
    }

    if (serverPort != null) {
        config.server_port = serverPort.toInt()
    }

    if (bufferSize != null) {
        config.buffer_size = bufferSize.toInt()
    }

    if (weight != null) {
        config.slave_weight = weight.toShort()
    }
    if (tranHost != null) {
        config.dstHost = tranHost
    }
    if (proxyConnectTimeout != null) {
        config.proxy_connect_timeout = proxyConnectTimeout.toLong()
    }
    if (proxyReadTimeout != null) {
        config.proxy_read_timeout = proxyReadTimeout.toLong()
    }
    if (proxyWriteTimeout != null) {
        config.proxy_write_timeout = proxyWriteTimeout.toLong()
    }
}

fun loggingConfig(logFilePath: String) {
    //声明日志文件存储路径以及文件名、格式
    val prop = Properties()
    //配置日志输出的格式
    if (logFilePath.isNotEmpty()) {
        prop.setProperty("log4j.rootLogger", "INFO, stdout, toFile")
        prop.setProperty("log4j.appender.toFile", "org.apache.log4j.DailyRollingFileAppender")
        prop.setProperty("log4j.appender.toFile.File", logFilePath)
        prop.setProperty("log4j.appender.toFile.Append", "true")
        prop.setProperty("log4j.appender.toFile.Threshold", "INFO")
        prop.setProperty("log4j.appender.toFile.layout", "org.apache.log4j.PatternLayout")
        prop.setProperty("log4j.appender.toFile.layout.ConversionPattern", "%-d{yyyy-MM-dd HH:mm:ss} | %l |  %m%n")
    } else {
        prop.setProperty("log4j.rootLogger", "INFO, stdout")
    }
    prop.setProperty("log4j.appender.file.encoding", "UTF-8")

    prop.setProperty("log4j.appender.stdout", "org.apache.log4j.ConsoleAppender")
    prop.setProperty("log4j.appender.stdout.Target", "System.out")
    prop.setProperty("log4j.appender.stdout.layout", "org.apache.log4j.PatternLayout")
    prop.setProperty("log4j.appender.stdout.layout.ConversionPattern", "%-d{yyyy-MM-dd HH:mm:ss} | %l |  %m%n")

    PropertyConfigurator.configure(prop)
}
