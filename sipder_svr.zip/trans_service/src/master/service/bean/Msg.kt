package master.service.bean

import io.netty.handler.codec.http.HttpMethod
import java.util.*

/**
 * Created by huang on 2017/6/26.
 */

data class Msg(var opt: String? = null, var data: String? = null)

data class HttpMsg(var uuid: String? = null, var isSync: Boolean? = null, var uri: String? = null, var content: String? = null, var headers: String? = null, var method: String? = null)

data class HeartMsg(var uuid: String?, var weight: Short, var timestamp: Long)

data class Http(var param: HashMap<String, String>, var header: HashMap<String, String>, var method: HttpMethod, var uri: String, var content: ByteArray? = null)

data class ProxyResponseMsg(var uuid: String?, var msg:String?)

data class Info(val machineCount: Int, val machineList: LinkedList<String>)