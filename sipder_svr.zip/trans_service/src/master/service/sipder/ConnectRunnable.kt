package service.sipder

import java.nio.channels.SelectionKey
import java.nio.channels.Selector
import java.nio.channels.ServerSocketChannel
import java.nio.channels.SocketChannel
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Created by huang on 2017/6/23.
 */
class ConnectRunnable(val serverSelector: Selector) : Runnable {

    val pool: ExecutorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors() * 4)

    override fun run() {
        while (true) {
            val count = serverSelector.select(20000)
            if (count <= 0) continue
            val keys = serverSelector.selectedKeys().iterator()
            while (keys.hasNext()) {
                val key = keys.next()
                if (key.isAcceptable) {
                    val channel = key.channel() as? ServerSocketChannel
                    val clientChannel = channel?.accept()
                    clientChannel?.configureBlocking(false)
                    clientChannel?.register(serverSelector, SelectionKey.OP_READ)
                } else if (key.isReadable) {
                    val socketChannel = (key.channel() as SocketChannel)
                    pool.execute(WorkRunnable(socketChannel))
                }
                keys.remove()  // 删除此消息
            }
        }
    }
}