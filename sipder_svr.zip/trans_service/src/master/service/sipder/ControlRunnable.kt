package service.sipder

import java.nio.channels.Selector
import java.nio.channels.SocketChannel
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Created by huang on 2017/6/23.
 */
class ControlRunnable(val clientSelector: Selector) : Runnable {
    val pool: ExecutorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors() * 4)
    override fun run() {
//        while (true) {
//            if (clientSelector.select(10000) <= 0) continue
//            val keys = clientSelector.selectedKeys().iterator()
//            while (keys.hasNext()) {
//                val key = keys.next()
//                keys.remove()  // 删除此消息
//                if (key.isReadable) {
//                    val socketChannel = (key.channel() as SocketChannel)
//                    pool.execute(WorkRunnable(socketChannel))
//                }
//            }
//        }
    }
}