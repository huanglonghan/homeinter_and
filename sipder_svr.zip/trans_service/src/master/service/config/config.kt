package master.service.config

/**
 * Created by huang on 2017/6/28.
 */
object config {
    const val DEF_TCP_SERVER_HOST = "0.0.0.0"
    const val DEF_TCP_SERVER_PORT = 9501
    const val DEF_HTTP_SERVER_HOST = DEF_TCP_SERVER_HOST
    const val DEF_HTTP_SERVER_PORT = DEF_TCP_SERVER_PORT + 1

    const val HTTP_SUCCEED = 200
    const val HTTP_SUCCEED_MSG = "OK"
    const val DEF_BUFFER_SIZE = 8 * 1024
    const val PARAM_OPT = "opt"
    const val HTTP_PROXY_REQUEST = "http_request"

    const val DEF_SYNC_TASK_TIMEOUT = 10
    const val DEF_GET_PROXY_REY_COUNT = 5
    const val DEF_MACHINE_INVALID_TIMEOUT = 5

    var tcp_server_host = DEF_TCP_SERVER_HOST
    var tcp_server_port = DEF_TCP_SERVER_PORT
    var http_server_host = DEF_HTTP_SERVER_HOST
    var http_server_port = DEF_HTTP_SERVER_PORT + 1

    var buffer_size = DEF_BUFFER_SIZE

    var sync_task_timeout = DEF_SYNC_TASK_TIMEOUT
    var get_proxy_rey_count = DEF_GET_PROXY_REY_COUNT
    var machine_invalid_timeout = DEF_MACHINE_INVALID_TIMEOUT

}