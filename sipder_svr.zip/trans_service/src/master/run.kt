import io.netty.util.internal.logging.InternalLogger
import io.netty.util.internal.logging.Log4J2LoggerFactory
import master.service.config.config
import org.apache.commons.cli.DefaultParser
import org.apache.commons.cli.Options
import org.apache.log4j.PropertyConfigurator
import org.ini4j.Ini
import service.http.HttpServer
import service.sipder.SpiderManager
import java.io.File
import java.util.*


/**
 * Created by huang on 2017/6/20.
 */

object Logging {
    private var _logging: InternalLogger? = null
    val log: InternalLogger
        get() {
            if (_logging == null) {
                _logging = Log4J2LoggerFactory.getInstance("main.class")
            }
            return _logging!!
        }
}

fun main(args: Array<String>) {

    val parser = DefaultParser()
    val options = Options()
    options.addOption("c", "config", true, "config file path")
    options.addOption("l", "log", true, "log path")
    options.addOption("h", "help", false, "help description")

    val commandLine = parser.parse(options, args)

    if (commandLine.hasOption('h')) {
        System.out.println("Demo: java -jar *.jar -c path [-l path]")
        System.exit(0)
        return
    }

    var logPath = ""
    if (commandLine.hasOption('l')) {
        logPath = commandLine.getOptionValue('l')
    }
    loggingConfig(logPath)

    if (!commandLine.hasOption('c')) {
        System.out.println("Demo: java -jar *.jar -c path")
        System.exit(0)
        return
    }
    val path = commandLine.getOptionValue('c')
    val ini: Ini
    try {
        ini = Ini(File(path))
        initConfig(ini)
    } catch (e: Exception) {
        System.out.println("config file format error !")
        System.exit(0)
        return
    }

    Logging.log.info("服务启动成功!!")
    Logging.log.info("配置文件路径: " + path)
    Logging.log.info("tcp:" + config.tcp_server_host + ":" + config.tcp_server_port)
    Logging.log.info("http:" + config.http_server_host + ":" + config.http_server_port)

    SpiderManager.runSpiderManageServer()
    HttpServer.runHttpServer()
}

fun initConfig(ini: Ini) {
    val tcpHost = ini.get("moplus", "tcp_server_host")
    val tcpPort = ini.get("moplus", "tcp_server_port")
    val httpHost = ini.get("moplus", "http_server_host")
    val httpPort = ini.get("moplus", "http_server_port")
    val bufferSize = ini.get("moplus", "msg_buffer_size")
    val syncTimeout = ini.get("moplus", "sync_task_timeout")
    val proxyTryCount = ini.get("moplus", "proxy_rey_count")
    val machineTimeout = ini.get("moplus", "machine_invalid_timeout")

    if (tcpHost != null) {
        config.tcp_server_host = tcpHost
    }

    if (tcpPort != null) {
        config.tcp_server_port = tcpPort.toInt()
    }

    if (httpHost != null) {
        config.http_server_host = httpHost
    } else {
        config.http_server_host = config.tcp_server_host
    }

    if (httpPort != null) {
        config.http_server_port = httpPort.toInt()
    } else {
        config.http_server_port = config.tcp_server_port + 1
    }

    if (bufferSize != null) {
        config.buffer_size = bufferSize.toInt()
    }

    if (syncTimeout != null) {
        config.sync_task_timeout = syncTimeout.toInt()
    }
    if (proxyTryCount != null) {
        config.get_proxy_rey_count = proxyTryCount.toInt()
    }
    if (machineTimeout != null) {
        config.machine_invalid_timeout = machineTimeout.toInt()
    }
}

fun loggingConfig(logFilePath: String) {
    //声明日志文件存储路径以及文件名、格式
    val prop = Properties()
    //配置日志输出的格式
    if (logFilePath.isNotEmpty()) {
        prop.setProperty("log4j.rootLogger", "INFO, stdout, toFile")
        prop.setProperty("log4j.appender.toFile", "org.apache.log4j.DailyRollingFileAppender")
        prop.setProperty("log4j.appender.toFile.File", logFilePath)
        prop.setProperty("log4j.appender.toFile.Append", "true")
        prop.setProperty("log4j.appender.toFile.Threshold", "INFO")
        prop.setProperty("log4j.appender.toFile.layout", "org.apache.log4j.PatternLayout")
        prop.setProperty("log4j.appender.toFile.layout.ConversionPattern", "%-d{yyyy-MM-dd HH:mm:ss} | %l |  %m%n")
    } else {
        prop.setProperty("log4j.rootLogger", "INFO, stdout")
    }
    prop.setProperty("log4j.appender.file.encoding", "UTF-8")

    prop.setProperty("log4j.appender.stdout", "org.apache.log4j.ConsoleAppender")
    prop.setProperty("log4j.appender.stdout.Target", "System.out")
    prop.setProperty("log4j.appender.stdout.layout", "org.apache.log4j.PatternLayout")
    prop.setProperty("log4j.appender.stdout.layout.ConversionPattern", "%-d{yyyy-MM-dd HH:mm:ss} | %l |  %m%n")

    PropertyConfigurator.configure(prop)
}
